# Guion literal per al vídeo de defensa — PersonalBet

> **Nota:** Per a la presentació oral en viu, utilitza **`Supertutorial_PersonalBet.md`** (sense referències a vídeo ni minuts).

**Alumne:** Alberto Martí Armiñana · **Tutor:** Enric Climent Martí · **Cicle:** DAM  
**Durada estimada:** 38–42 minuts (llegeix amb calma; pausa entre blocs)

**Instruccions:** El text entre cometes és el que has de dir. Les línies amb **[MOSTRAR]** indiquen què fer a pantalla.

---

## BLOC 1 — Presentació (2 minuts)

**[MOSTRAR]** Portada del projecte o pantalla d’inici de l’app.

«Bon dia. Em dic Alberto Martí Armiñana i este és el meu projecte de fi de cicle del DAM: **PersonalBet**, una aplicació Android per al control personal d’apostes esportives.

L’objectiu de l’app és que l’usuari puga registrar les seues apostes, veure estadístiques de rendiment, gestionar el diners en cada casa d’apostes i exportar o importar dades en CSV per fer còpies de seguretat.

El projecte està desenvolupat en **Kotlin**, amb **Room** per a la base de dades, **SharedPreferences** per a la configuració i les comptes, i una arquitectura de **Single Activity** amb diversos **Fragments**. El codi font està al repositori de GitHub: almartar barra PersonalBet.

Si no puc presentar-me oralment, este vídeo substitueix la defensa en viu.

Abans d’entrar al codi i a la demo de l’aplicació, explicaré **com funcionen les apostes esportives en el món real**: conceptes com tipster, bankroll, stake, ROI o yield, mercats, etc. Així el tribunal entén el context del problema que resol PersonalBet. Després explicaré l’arquitectura tècnica, el codi font i una demostració de l’app.»

---

## BLOC 2 — Com funcionen les apostes en el món real (7 minuts)

**[MOSTRAR]** Diapositiva en blanc, pissarra o pantalla sense codi. Opcional: un partit de futbol o la web d’una casa d’apostes (sense promocionar joc).

### Què és una apuesta esportiva

«En el món real, una **apuesta esportiva** és una previsió sobre el resultat d’un esdeveniment — per exemple un partit de futbol, bàsquet o tennis — en què l’usuari arrisca una quantitat de diners. Si encerta, cobra un benefici segons la **quota**; si falla, perd l’import apostat.

Les apostes les ofereixen les **cases d’apostes** o **bookmakers**: empreses legalment regulades — com Bet365, Winamax o Bwin — que publiquen quotes i gestionen el saldo de l’usuari. Cada casa té la seua pròpia app i historial, però **no agrupa** les dades entre operadors ni calcula el rendiment global de l’usuari. Este buit és precisament el que motiva PersonalBet.»

### Per què hi ha diverses cases: buscar la millor quota

«Molts apostadors utilitzen **diverses cases** no per casualitat, sinó per una raó concreta: **trobar la quota més alta** per al mateix pronòstic.

Cada operador fixa les seues pròpies quotes. En un mateix partit, el mateix mercat pot tindre preus diferents.

Exemple real: en el partit **València – Elx**, si vull apostar al **signe 1** — és a dir, que guanye el València — pot ser que a **Bet365** la quota siga **1,70** i a **Winamax** **1,75**.

La diferència pot semblar petita — només cinc centésimes —, però **a la llarga és notable**. Si apostes 100 euros, a 1,70 el benefici net en guanyar seria 70 euros; a 1,75 seria 75 euros. Són 5 euros més per la mateixa apuesta. Multiplicat per centenars d’apostes a l’any, eixe increment pot marcar la diferència entre un balanç positiu i un negatiu.

Per això els apostadors més avançats comparen quotes abans de jugar. I per això PersonalBet permet registrar **en quina casa** es va fer cada apuesta i veure el rendiment **per casa**, no només el global.»

### Quota, stake i benefici

«La **quota** — en anglès **odds** — és el multiplicador del benefici. Si la quota és 2,00 i apostes 10 euros, en guanyar cobres 20 euros en total: recuperes els 10 apostats més 10 de benefici net.

L’**stake** és l’**import apostat** en euros en una operació concreta. És la xifra que l’usuari posa en joc en cada apuesta.

Si l’apuesta **guanya**, el benefici net és: stake multiplicat per quota menys u. Exemple: 10 euros a quota 1,85 donen 8,50 euros de benefici net.

Si l’apuesta **perd**, la pèrdua és igual al stake: menys 10 euros.

Mentre l’esdeveniment no s’ha jugat, l’apuesta està **pendent**. PersonalBet reflectix estos tres estats: pendent, guanyada i perduda.»

### Tipster

«Un **tipster** és la persona o font que **recomana** l’apuesta: pot ser tu mateix, un analista d’Internet, un grup de Telegram o un servei de pronòstics.

En la pràctica, molts apostadors volen saber si un tipster concret és rendible a llarg termini. Per això PersonalBet permet assignar un tipster a cada apuesta i filtrar estadístiques per tipster: per veure quant s’ha guanyat o perdut seguint les recomanacions d’aquella font.»

### Bankroll

«El **bankroll** és el **capital total** que l’usuari destina a apostar: el “pressupost” del joc, diguem-ho així. No és el saldo d’una sola apuesta, sinó el conjunt de diners que té disponibles per a apostar de forma responsable.

En la realitat el bankroll sovint està **fragmentat**: una part del diners està a Bet365, una altra a Winamax, hi ha hagut dipòsits i retirades… PersonalBet modela això a la pantalla de **Comptes**: per cada casa es registra el saldo inicial, els ingressos, les retirades i el benefici de les apostes, per obtindre un saldo coherent.»

### Mercats, esport i tipus d’apuesta

«Dins d’un mateix partit hi ha molts **mercats** o tipus de pronòstic:

- **Ganador** o 1X2: qui guanya o si hi ha empat.
- **Goles** o **Over/Under**: si es marquen més o menys d’un nombre de gols.
- **Handicap**: avantatge o desavantatge virtual a un equip.
- **Corners**, **targetes**, **jugadors**, etc.

L’**esport** identifica la competició — futbol, bàsquet, tennis.

El **tipus d’apuesta** distingeix si es va fer **abans del partit** — **PreMatch** — o **en directe** mentre es juga — **Live**. El rendiment pot variar molt entre tots dos, i per això l’app permet filtrar per Live o PreMatch.»

### ROI, yield i percentatge d’encerts

«Per mesurar si un apostador — o un tipster — és rendible **a llarg termini**, s’utilitzen mètriques estàndard:

El **percentatge d’encerts** o **hit rate** és: guanyades dividit entre total de apostes resoltes, per 100. Exemple: 6 guanyades i 4 perdudes són un 60 per cent d’encerts. Açò sol no n’hi ha prou: es pot guanyar sovint amb quotes baixes i perdre diners.

El **yield** — i el **ROI**, que en apostes solen ser el mateix concepte — mesura **què de rendible és un tipster o una estrategia a llarg termini** sobre el total que s’ha apostat.

La fórmula és: benefici net dividit entre total apostat en apostes **ja resoltes**, multiplicat per 100.

Un **yield del 5 per cent** vol dir que, de mitjana, per cada **100 euros apostats** en conjunt — no en una sola apuesta, sinó sumant tot el volum liquidat — s’han guanyat **5 euros nets** de benefici. No és que cada apuesta done 5 euros; és una mitjana de rendiment sobre el volum total.

Exemple: si en un mes has apostat 2.000 euros en apostes ja resoltes i el teu benefici net és 100 euros, el yield és un 5 per cent. Això indica que la teua estrategia — o el tipster que segueixes — és rendible a llarg termini.

Un yield positiu i estable al llarg de centenars d’apostes és el que busca un apostador seriós. Un yield negatiu indica que, amb eixa quota i eixa gestió, es perd diners malgrat algun encert aïllat.

En **PersonalBet**, la pantalla d’Estadístiques calcula este yield — ho mostrem com a ROI — i permet filtrar-lo per tipster, per casa, per mercat o per període, per veure si una font concreta és realment rendible o no.

**Important:** les apostes **pendents** no entren en yield, ROI ni en encerts, perquè encara no s’han liquidat i distorsionarien el resultat.»

### Per què cal una app com PersonalBet

«Resumint el context del món real:

Les apps de les cases mostren el saldo oficial, però **no** calculen el ROI global entre diverses cases, **no** agrupen per tipster ni per mercat, i **no** integren dipòsits i retirades amb el rendiment de les apostes.

PersonalBet no realitza apostes — l’usuari introdueix manualment les dades —, però ofereix una **visió unificada** del rendiment, amb filtres, exportació CSV i gestió de bankroll per casa.

A partir d’ací passaré a explicar com he implementat tot això en codi Android.»

---

## BLOC 3 — Arquitectura general (3 minuts)

**[MOSTRAR]** Diagrama de la memòria o l’estructura de carpetes a Android Studio.

«L’arquitectura de PersonalBet segueix el patró **Single Activity**. Només hi ha una activitat, `MainActivity`, i tota la interfície es construeix amb **Fragments** que es substitueixen dins d’un contenidor.

La persistència es divideix en dues capes perquè cada tecnologia fa el que millor sap fer.

Primer, **Room**, que és una capa sobre SQLite. Aquí guardem les **apostes**: cada fila té casa, esport, tipster, esdeveniment, quota, stake, tipus, mercat, resultat i data. Són dades estructurades que necessitem consultar, filtrar i ordenar.

Segon, **SharedPreferences**. Aquí guardem la **configuració** de llistes — cases, tipsters, mercats, tipus Live o PreMatch — i també les **comptes de cada casa**: saldo inicial, dipòsits i retirades.

Per a la interfície utilitzem **View Binding**: cada pantalla infla el seu layout XML i accedeix a les vistes sense `findViewById`.

Per no bloquejar la interfície quan escrivim a la base de dades, utilitzem **coroutines** de Kotlin: `lifecycleScope.launch` i `withContext(Dispatchers.IO)` per a les operacions pesades.

L’estructura de paquets és clara: el paquet `data` conté Room; el paquet `config` conté les Preferences; i dins de `ui` tenim welcome, bets, add, stats, annual i config.»

---

## BLOC 4 — Capa de dades Room (5 minuts)

**[MOSTRAR]** Fitxers `Bet.kt`, `BetResult.kt`, `BetDao.kt` i `AppDatabase.kt` a Android Studio.

### Entitat Bet

«La classe **Bet** és l’entitat Room. Està anotada amb `@Entity` i la taula es diu `bets`.

Cada aposta té un **id** autogenerat, la **casa** o bookmaker, l’**esport**, el **tipster**, la **descripció de l’esdeveniment**, la **quota** en decimal, l’**import apostat** o stake, el **grup de tipus** — LIVE o PREMATCH —, el **nom del tipus**, el **mercat**, el **resultat** com a text, i la **data** en mil·lisegons.

El resultat no és un enum directament a Room sinó un String, per compatibilitat amb el CSV i flexibilitat. Per a això tenim l’enum auxiliar **BetResult**.»

### Enum BetResult

«**BetResult** té tres valors: **PENDING** per a pendents, **WON** per a guanyades i **LOST** per a perdudes.

El mètode `fromStorage` converteix el text de la base de dades a enum. Si el valor és desconegut, retorna PENDING per seguretat.

La propietat `storageValue` retorna el String que guardem a Room i als fitxers CSV.»

### BetDao

«**BetDao** és la interfície d’accés a dades. Room genera la implementació en compilació.

Per a lectura tenim `getAllBets`, que retorna totes les apostes ordenades per data descendent, i `getById` per carregar una aposta concreta quan l’editem.

Per a escriptura tenim `insert` per a altes noves, `update` per a edicions completes, `updateResult` per canviar només el resultat des de la llista, `delete` per a una aposta i `deleteAll` per buidar tota la taula des de Configuració.

A més hi ha consultes agregades en SQL: `getTotalNetProfit` calcula el benefici net global; `getTotalStakedSettled` suma el stake de les resoltes; `countWins` i `countLosses` compten guanyades i perdudes; i `getNetProfitBetween` filtra per rang de dates.

La fórmula del benefici a SQL és la mateixa que a la interfície: si ha guanyat, stake per quota menys u; si ha perdut, menys stake; les pendents no compten.»

### AppDatabase i migració

«**AppDatabase** és un singleton: una sola instància a tota l’app mitjançant `getInstance`.

La base de dades està en versió 2. Quan vam afegir les columnes `betTypeGroup`, `betTypeName` i `marketType`, vam definir la migració **MIGRATION_1_2** amb ALTER TABLE i valors per defecte, per no perdre les apostes dels usuaris que actualitzaven l’app.

`PersonalBetApplication`, al `onCreate`, crida `AppDatabase.getInstance` i assigna la base de dades a una variable global perquè qualsevol Fragment puga accedir-hi.»

---

## BLOC 5 — SharedPreferences (4 minuts)

**[MOSTRAR]** `AppConfigStore.kt` i `BookmakerAccountsStore.kt`.

### AppConfigStore

«**AppConfigStore** guarda la configuració de llistes al fitxer `personalbet_config`.

La classe `ConfigData` agrupa quatre camps CSV: bookmakers, tipsters, markets i bet types. En una instal·lació nova **totes les llistes comencen buides** — no hi ha Bet365 ni cap valor fictici per defecte. L’usuari professional defineix les seues cases, tipsters, mercats i tipus a **Configuració** i prem **Guardar**.

En guardar, `ConfigFragment` crida `restoreAccount` per a cada casa del CSV, de manera que apareguen a la pestanya **Comptes** encara sense apuestas.

Els mètodes principals són `get` per llegir, `save` per guardar des de Configuració, `parseCsv` per convertir el text en llistes per als spinners, `hasSeenTutorial` per saber si ja es va mostrar el tutorial, i `markTutorialSeen` quan l’usuari el tanca.

Si s’intenta registrar una apuesta sense haver configurat res, `AddBetFragment` mostra un error i no deixa guardar.»

### BookmakerAccountsStore

«**BookmakerAccountsStore** gestiona el diners a cada casa, independent de les apostes a Room.

Per cada bookmaker guardem el **saldo inicial**, una llista serialitzada de **dipòsits** i una altra de **retirades**. Cada moviment té un identificador UUID, un import i una data.

Els mètodes principals són: `guardarSaldoInicial`, `guardarIngreso` i `guardarRetirada` amb data; `getFor` per obtenir totals, opcionalment filtrats per rang; `getMovements` per editar un moviment concret; `updateMovementAmount` per canviar l’import; `deleteAccount` per eliminar una compte de la vista; i `restoreAccount` quan una casa apareix a les apostes o a la configuració.

La fórmula del saldo que mostrem a la pantalla de Comptes és: saldo inicial més dipòsits menys retirades més el benefici de les apostes d’aquella casa. El benefici només suma guanyades i resta perdudes; les pendents no entren.»

---

## BLOC 6 — Navegació: Application i MainActivity (3 minuts)

**[MOSTRAR]** `MainActivity.kt` i l’app obrint-se.

«Al arrancar l’app, primer s’executa **PersonalBetApplication** i es crea la base de dades. Després obre **MainActivity**.

En el primer arrancament, quan `savedInstanceState` és null, es mostra el **WelcomeFragment** i la barra inferior està oculta.

Quan l’usuari prem **Empezar**, es crida `openHomeFromWelcome`: es neteja el back stack, es mostra la llista d’apostes i apareix el **BottomNavigationView** amb quatre pestanyes: Apostes, Estadístiques, Comptes i Configuració.

Quan canviem de pestanya, `replaceMainFragment` buida el back stack i substitueix el fragment principal.

Quan obrim el formulari d’alta o edició amb el FAB o el botó editar, fem `addToBackStack`. Un listener observa la pila: si hi ha fragments apilats, amaga la barra inferior; quan tornem enrere amb `popBackStack`, la torna a mostrar.

`openAddBetScreen` obre `AddBetFragment` buit. `openEditBetScreen` obre el mateix fragment però amb l’id de l’aposta a editar.

Al **AndroidManifest** declaram `PersonalBetApplication`, el permís d’escriptura a emmagatzematge només per a Android 28 o inferior per als CSV, i `MainActivity` com a punt d’entrada amb `adjustResize` perquè el teclat no tape el formulari.»

---

## BLOC 7 — Demo: Bienvenida i llista (3 minuts)

**[MOSTRAR]** App en viu — pantalla de benvinguda i llista.

«Ara veiem l’app en funcionament.

En obrir-la per primera vegada apareix la **pantalla de benvinguda**. Si l’usuari no ha vist el tutorial, es mostra automàticament un diàleg amb les instruccions bàsiques. En tancar-lo es marca com a vist a Preferences.

El botó **Empezar** porta directament a la **llista d’apostes**.

`BetsListFragment` carrega totes les apostes amb `loadBets` en una coroutine. Guarda la llista a memòria i aplica filtres.

L’usuari pot filtrar per **data** — tria dia des de i dia fins —, per **resultat** — totes, guanyades, perdudes o pendents —, per **casa** i per **tipster**. Els dos últims es generen dinàmicament a partir de les apostes existents.

Cada fila la pinta **BetsAdapter**. Mostra l’esdeveniment, metadades, stake, i si ha guanyat mostra el benefici en verd; si ha perdut, la pèrdua en roig; si està pendent, en gris.

Des de cada fila podem **verificar** el resultat amb un diàleg sense obrir el formulari complet, **editar** amb el botó del **làpiz** o **eliminar** amb la paperera. Abans d’eliminar, `confirmDeleteBet` mostra un diàleg de confirmació; només si l’usuari accepta es crida `betDao.delete` i es recarrega la llista.

El botó flotant **més** obre el formulari d’alta.»

---

## BLOC 8 — Demo: Alta i edició d’apostes (4 minuts)

**[MOSTRAR]** Formulari AddBetFragment.

«**AddBetFragment** serveix tant per a altes com per a edicions.

En mode alta, tots els camps estan buits excepte la data d’avui. En mode edició, `newEditInstance` passa l’id per arguments, es carrega l’aposta amb `getById` i es omplen els camps.

Els spinners de casa, tipster, mercat i tipus llegeixen **AppConfigStore** — només el que l’usuari ha guardat a Configuració.

L’usuari omple esport, esdeveniment, quota i stake. `trySave` valida: que hi hagi configuració; casa, esport i esdeveniment obligatoris; quota i stake majors que zero; accepta coma o punt decimal; i que el **stake no superi el saldo disponible** a aquella casa (`checkInsufficientBalance`), tenint en compte dipòsits, retirades, benefici de resoltes i stakes de pendents.

El tipus Live o PreMatch es normalitza a LIVE o PREMATCH al camp `betTypeGroup`.

Si tot és correcte, es construeix un objecte `Bet` i es fa `insert` o `update` en segon pla. Després `popBackStack` torna a la llista, que es refresca al `onResume`.

També hem aplicat **insets** per al teclat: quan s’obri el teclat, el formulari puja el padding inferior perquè el botó Guardar siga visible.»

---

## BLOC 9 — Demo: Estadístiques (4 minuts)

**[MOSTRAR]** Pestanya Estadístiques.

«A **StatsFragment** l’usuari analitza el rendiment amb molts filtres.

Pot triar període **global** o **rang de dates**. En rang apareix el botó per seleccionar des de i fins.

L’**àmbit** pot ser General, Tipster o Cuenta — casa d’apostes. Si tria Tipster o Cuenta, apareix un spinner extra amb tots els valors o Todos.

També filtra per tipus d’aposta Live o PreMatch, per mercat i per esport. Mercats i esports es construeixen dinàmicament de les apostes.

El mètode `renderStats` filtra la llista i després només compta apostes **resoltes**: guanyades i perdudes. Les pendents no entren a les estadístiques.

Per a cada aposta resolta calcula: guanyades, perdudes, total apostat, benefici net, percentatge d’encert i ROI.

Benefici guanyada: stake per quota menys u. Pèrdua: menys stake. Hit rate: guanyades entre total resoltes per cent. ROI: benefici net entre total apostat per cent.

Els números es mostren en verd si són positius, vermell si negatius i gris si són zero.»

---

## BLOC 10 — Demo: Comptes per casa (4 minuts)

**[MOSTRAR]** Pestanya Comptes / Resum anual.

«**AnnualSummaryFragment** mostra una targeta per cada casa d’apostes.

Primer combina les cases de la configuració i les que apareixen a les apostes, excloent les que l’usuari ha eliminat.

Per a cada casa calcula dipòsits i retirades — amb filtre de dates si el període és per rang —, el saldo inicial, el benefici de les apostes d’aquella casa, i el **saldo final** amb la fórmula que hem dit abans.

Al final mostra totals globals de saldo, dipòsits i retirades.

Si l’usuari toca una targeta, obre un menú: **dipositar**, **retirar**, **editar** un moviment anterior, **establir saldo inicial** o **eliminar compte**.

En retirar validem que l’import no supere el saldo actual. En depositar o retirar demana la data — avui o manual amb DatePicker.

Tots els canvis es guarden a **BookmakerAccountsStore** i es refresca la vista amb `loadAccounts`.»

---

## BLOC 11 — Configuració i CSV (3 minuts)

**[MOSTRAR]** Pestanya Configuració i carpeta Descargas si és possible.

«**ConfigFragment** concentra la configuració i les operacions de dades.

L’usuari edita les llistes CSV de cases, tipsters, mercats i tipus, i prem **Guardar configuración**. Es persisteix a AppConfigStore.

El botó de **tutorial** torna a obrir el diàleg d’ajuda.

**Eliminar totes les apostes** demana confirmació i executa `deleteAll` a Room. No borra les comptes de Preferences.

**Exportar** genera dos fitxers CSV a la carpeta Descargas PersonalBet: `apuestas_export.csv` amb totes les apostes, i `cuentas_export.csv` amb el resum de cada casa. En Android 10 i superior utilitza MediaStore; en versions antigues, carpeta pública.

**Importar apostes** obre el selector de fitxers, llegeix el CSV fila a fila, ignora la capçalera i les files incompletes, i fa insert per cada aposta vàlida.

**Importar comptes** reinicia cada casa abans d’importar per evitar duplicats, i aplica saldo inicial, dipòsits i retirades agregats.

El parseig CSV suporta camps entre comilles i números amb coma o punt.»

---

## BLOC 12 — Preguntes que poden fer al tribunal (2 minuts)

**[MOSTRAR]** Tu a càmera o diapositiva de resum.

«Per si el tribunal té dubtes, responc breument les preguntes més habituals.

**Per què Room i no només Preferences?** Perquè les apostes són moltes files amb consultes, filtres i ordenació. SQLite escala millor.

**Per què Preferences per a les comptes?** Són pocs registres per casa, estructura clau-valor, i es combinen amb el càlcul de benefici de les apostes a la interfície.

**Com evites bloquejar la UI?** Coroutines amb Dispatchers.IO per a base de dades i fitxers.

**Com navegues?** Un sol FragmentManager, replace per a pestanyes, back stack només al formulari.

**Què passa si actualitzes l’app?** La migració 1 a 2 afegeix columnes sense esborrar dades.

**Com es calcula el ROI?** Benefici net entre total apostat, només apostes resoltes.»

---

## BLOC 13 — Tancament (1 minut)

**[MOSTRAR]** Logo del centre, GitHub o USB del projecte.

«En resum, PersonalBet és una aplicació completa per a gestió personal d’apostes esportives: registre, estadístiques, comptes per casa, exportació CSV i configuració flexible.

El codi està organitzat en capes clares — dades, configuració i interfície — i utilitza les tecnologies estàndard del temari de Android del DAM.

La memòria completa del projecte, el codi font, les captures i esta guia estan al suport USB i al repositori de GitHub.

Moltes gràcies per la vostra atenció.»

---

*Guion literal — PersonalBet — IES Dr. Lluís Simarro — Curs 2025/2026*
