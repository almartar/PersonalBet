# Supertutorial PersonalBet — Guia completa per a la presentació oral

**Alumne:** Alberto Martí Armiñana · **Tutor:** Enric Climent Martí · **Cicle:** DAM  
**Centre:** IES Dr. Lluís Simarro · **Curs:** 2025–2026  
**Repositori:** https://github.com/almartar/PersonalBet

Aquest document és un **supertutorial** per a la defensa oral del projecte. Complement ideal: **`Presentacio_Supertutorial_PersonalBet.pptx`** (mateix contingut en diapositives). Combina el context del món real de les apostes esportives, l’explicació del funcionament de l’aplicació i el detall del codi font. Pots seguir-lo com a guia mentre presentes en viu davant del tribunal.

---

## Índex

1. Introducció al projecte  
2. Les apostes esportives en el món real  
3. Arquitectura de l’aplicació  
4. Capa de dades — Room  
5. Configuració — SharedPreferences  
6. Navegació i arranc de l’app  
7. Pantalles i codi (Fragments)  
8. Fluxos d’ús per a la demostració  
9. Exportació i importació CSV  
10. Preguntes freqüents  
11. Resum per a tancar la presentació  

---

## 1. Introducció al projecte

**PersonalBet** és una aplicació Android nativa desenvolupada en **Kotlin** per al control personal d’apostes esportives. L’usuari registra manualment les seues apostes, consulta estadístiques de rendiment, gestiona el diners en cada casa d’apostes i pot exportar o importar dades en CSV.

**Tecnologies principals:** Room (SQLite), SharedPreferences, Single Activity amb Fragments, View Binding, Coroutines, Material Design.

**Què NO fa l’app (important per a la defensa):**

- **No es connecta** a cap casa d’apostes ni a cap API d’operadors
- **No ofereix quotes en línia** ni preus en temps real
- **No realitza apostes** en línia des de l’aplicació
- **No ofereix pronòstics** ni recomanacions de jugades
- **No automatitza res** — tot el registre és **manual**

**Públic objectiu:** usuaris **professionals** o avançats del sector: tipsters que controlen el rendiment dels seus clients, apostadors que gestionen bankroll entre diverses cases, o persones que ja aposten per compte propi i necessiten **anàlisi seriosa** (yield, ROI, filtres per tipster/mercat), no una app de joc ni una alternativa a les cases.

L’usuari professional **ja té la informació** (del tipster o de la seua pròpia jugada) i la **introdueix manualment** a PersonalBet per mantindre un diari estructurat i estadístiques fiables.

**Ordre suggerit per a la presentació:**

1. Context del món real (apostes, tipster, yield…)  
2. Problema que resol PersonalBet  
3. Arquitectura i persistència  
4. Demostració de l’app en viu  
5. Fragment de codi rellevant (Room, un Fragment…)  
6. Conclusions i GitHub  

---

## 2. Les apostes esportives en el món real

Abans d’entrar al codi convé explicar el domini del problema perquè el tribunal entenga per què existeix cada camp i cada pantalla.

### 2.1 Què és una apuesta esportiva

Una apuesta esportiva és una previsió sobre el resultat d’un esdeveniment — partit de futbol, bàsquet, tennis, etc. — en què l’usuari arrisca diners. Si encerta, cobra un benefici segons la **quota**; si falla, perd l’import apostat.

Les ofereixen les **cases d’apostes** o **bookmakers** (Bet365, Winamax, Bwin…): empreses regulades que publiquen quotes i gestionen el saldo de l’usuari.

### 2.2 Per què hi ha diverses cases: buscar la millor quota

Molts apostadors — i especialment els **tipsters** — comparen **diverses cases** per trobar la **quota més alta** en el mateix pronòstic. Cada operador fixa preus diferents, i el pronosticador **tria la casa** que ofereix millor valor.

**Exemple:** partit **València – Elx**, mercat **signe 1** (guanya el València). A **Bet365** la quota pot ser **1,70** i a **Winamax** **1,75**. El tipster recomana **Winamax** i els clients aposten allà. La diferència de 0,05 sembla petita, però **a la llarga és notable**: amb 100 € de stake, el benefici net en guanyar passa de 70 € a 75 €.

Per això PersonalBet registra la **casa que va indicar el tipster** i permet veure el rendiment **per operador** i **per tipster**.

### 2.3 Quota, stake i benefici

| Terme | Definició |
|-------|-----------|
| **Quota (odds)** | Multiplicador del benefici en decimal (ex.: 1,85) |
| **Stake** | Import apostat en euros en una operació |
| **Benefici net (guanyada)** | `stake × (quota − 1)` |
| **Pèrdua** | `−stake` |
| **Pendent** | Esdeveniment encara no resolt |

### 2.4 Tipster (pronosticador) i unitats de stake

Un **tipster** o **pronosticador** és qui **analitza i decideix tota la jugada** abans de recomanar-la als seus clients o seguidors. En concret, el tipster és qui tria:

- La **casa** o **bookmaker** (sovint després de comparar quotes entre operadors)
- L’**esport** (futbol, bàsquet, tennis…)
- L’**esdeveniment** (partit concret)
- El **mercat** (signe 1, goles, handicap…)
- El **tipus** d’apuesta (**PreMatch** o **Live**)
- La **quota** a la qual convé jugar
- La **unitat de stake** (per exemple **Stake 1**)

El **client o usuari** no reinventa la jugada: **segueix** la casa, el mercat i el tipus que ha indicat el tipster, i només adapta l’**import en euros** al seu propi **bankroll**.

En la pràctica el tipster **no diu un import fix en euros** a tothom, sinó una **unitat** — **«Stake 1»**. Cada client la converteix al seu percentatge de bankroll:

- **Stake 1 = 1 % del bankroll** (regla habitual de gestió conservadora)
- Bankroll 1.000 € → aposta **10 €**
- Bankroll 500 € → aposta **5 €**
- Bankroll 2.000 € → aposta **20 €**

Mateixa recomanació, mateix risc relatiu (1 %), imports diferents en euros. PersonalBet permet assignar **tipster** a cada apuesta i registrar l’**import real en €** que va apostar l’usuari, per filtrar estadístiques i veure si una font és rendible a llarg termini.

### 2.5 Bankroll

El **bankroll** és el **capital total** destinat a apostar. En la pràctica està **fragmentat** entre diverses cases, amb dipòsits i retirades. La pantalla **Comptes** modela això: saldo inicial, ingressos, retirades i benefici de les apostes per casa.

### 2.6 Mercats, esport i tipus d’apuesta

Dins d’un partit hi ha molts **mercats**: ganador (1X2), goles (Over/Under), handicap, corners, jugadors, etc.

El **tipus d’apuesta** distingeix **PreMatch** (abans del partit) i **Live** (en directe). El rendiment pot variar molt; l’app permet filtrar per ambdós.

### 2.7 Yield, ROI i percentatge d’encerts

| Mètrica | Què mesura |
|---------|------------|
| **Hit rate** | `guanyades / (guanyades + perdudes) × 100` — només resoltes |
| **Yield / ROI** | Rendiment a llarg termini: `benefici_net / total_apostat × 100` — només resoltes |

El **yield** indica **què de rendible és un tipster o una estrategia** amb moltes apostes. Un **yield del 5 %** vol dir que, de mitjana, per cada **100 € apostats** en conjunt (sumant tot el volum liquidat), s’obtenen **5 € nets** de benefici. No és per cada apuesta individual, sinó una mitjana sobre el total.

Exemple: 2.000 € apostats en resoltes i 100 € de benefici net → yield 5 %.

Les apostes **pendents** no entren en yield, ROI ni encerts.

### 2.8 Per què cal PersonalBet

Les apps de les cases mostren el saldo oficial però **no** unifiquen diversos operadors, **no** calculen yield per tipster o mercat, i **no** integren dipòsits/retirades amb el rendiment de les apostes. PersonalBet ofereix una **visió unificada** amb filtres, CSV i gestió de bankroll per casa.

---

## 3. Arquitectura de l’aplicació

### 3.1 Patró general

- **Single Activity:** només `MainActivity`; la UI són **Fragments** en un contenidor.
- **Persistència dual:**
  - **Room (SQLite):** apuestas — dades estructurades, consultes SQL, CRUD.
  - **SharedPreferences:** configuració (llistes CSV) i comptes per casa (dipòsits, retirades, saldo inicial).
- **View Binding** per a totes les pantalles.
- **Coroutines:** `lifecycleScope` + `Dispatchers.IO` per a base de dades i fitxers.

### 3.2 Estructura de paquets

```
com.example.personalbet/
├── PersonalBetApplication.kt
├── MainActivity.kt
├── data/          → Bet, BetResult, BetDao, AppDatabase
├── config/        → AppConfigStore, BookmakerAccountsStore
└── ui/
    ├── welcome/   → WelcomeFragment
    ├── help/      → TutorialDialog
    ├── bets/      → BetsListFragment, BetsAdapter
    ├── add/       → AddBetFragment
    ├── stats/     → StatsFragment
    ├── annual/    → AnnualSummaryFragment
    └── config/    → ConfigFragment
```

### 3.3 AndroidManifest.xml

| Element | Funció |
|---------|--------|
| `PersonalBetApplication` | Crea Room abans de qualsevol pantalla |
| `WRITE_EXTERNAL_STORAGE` (maxSdk 28) | CSV a Descargas en Android antics |
| `MainActivity` + LAUNCHER | Punt d’entrada |
| `adjustResize` | El teclat no tapa el formulari |

---

## 4. Capa de dades — Room

### 4.1 Entitat `Bet` (`data/Bet.kt`)

Taula Room: `bets`

| Camp | Tipus | Descripció |
|------|-------|------------|
| `id` | Long (PK) | Autogenerat; 0 en insert |
| `bookmaker` | String | Casa d’apostes |
| `sport` | String | Esport |
| `tipster` | String | Font de la recomanació |
| `eventDescription` | String | Esdeveniment |
| `odds` | Double | Quota decimal |
| `stake` | Double | Import apostat (€) |
| `betTypeGroup` | String | `LIVE` o `PREMATCH` |
| `betTypeName` | String | Nom visible (Live, PreMatch…) |
| `marketType` | String | Mercat |
| `result` | String | `PENDING`, `WON`, `LOST` |
| `datePlacedMillis` | Long | Data (inici del dia) |

El camp `result` és String per compatibilitat amb CSV; l’enum `BetResult` fa la conversió.

### 4.2 Enum `BetResult` (`data/BetResult.kt`)

| Valor | Significat |
|-------|------------|
| `PENDING` | Sense resoldre |
| `WON` | Guanyada |
| `LOST` | Perduda |

- `fromStorage(value)` — converteix text a enum; per defecte `PENDING`.
- `storageValue` — text per a Room i CSV.

### 4.3 `BetDao` (`data/BetDao.kt`)

**Lectura**

| Mètode | Funció |
|--------|--------|
| `getAllBets()` | Totes les apostes, data descendent |
| `getById(id)` | Una apuesta per editar |

**Escriptura**

| Mètode | Funció |
|--------|--------|
| `insert(bet)` | Alta nova |
| `update(bet)` | Edició completa |
| `updateResult(id, result)` | Canvi ràpid de resultat des de la llista |
| `delete(bet)` | Elimina una apuesta |
| `deleteAll()` | Buida la taula |

**Agregats SQL**

| Mètode | Funció |
|--------|--------|
| `getTotalNetProfit()` | Benefici net global |
| `getTotalStakedSettled()` | Suma stake de resoltes |
| `countWins()` / `countLosses()` | Comptadors |
| `getNetProfitBetween(from, to)` | Benefici en rang de dates |

`StatsFragment` i `AnnualSummaryFragment` recalculen en Kotlin amb filtres de la UI; el DAO ofereix totals globals sense recórrer la llista en memòria.

### 4.4 `AppDatabase` (`data/AppDatabase.kt`)

- Singleton amb `getInstance(context)`.
- Versió 2; migració `MIGRATION_1_2` afegeix `betTypeGroup`, `betTypeName`, `marketType` sense perdre dades.

### 4.5 `PersonalBetApplication`

Al `onCreate` inicialitza `AppDatabase` i exposa `PersonalBetApplication.database` per a tots els Fragments.

---

## 5. Configuració — SharedPreferences

### 5.1 `AppConfigStore` (`config/AppConfigStore.kt`)

Fitxer: `personalbet_config`

| Camp | Clau | Contingut per defecte |
|------|------|----------------------|
| `bookmakersCsv` | `bookmakers_csv` | **Buit** — l’usuari defineix les seues cases |
| `tipstersCsv` | `tipsters_csv` | **Buit** |
| `marketsCsv` | `markets_csv` | **Buit** |
| `betTypesCsv` | `bet_types_csv` | **Buit** |

**Primera configuració obligatòria:** en una instal·lació nova les llistes estan buides. Abans de registrar la primera apuesta, cal anar a **Configuració**, omplir almenys les cases (i, si cal, tipsters, mercats i tipus) i prémer **Guardar**. Si s’intenta guardar una apuesta sense configuració, `AddBetFragment` mostra un missatge d’error (`add_bet_error_config`).

Clau apart: `tutorial_seen` (boolean).

| Mètode | Funció |
|--------|--------|
| `get` / `save` | Llegir i guardar llistes |
| `parseCsv` | Text → llista per spinners |
| `hasSeenTutorial` / `markTutorialSeen` | Control del tutorial |

### 5.2 `BookmakerAccountsStore` (`config/BookmakerAccountsStore.kt`)

Fitxer: `personal_bet_accounts`

Per cada casa: saldo inicial, llistes de dipòsits i retirades (serialitzades amb id, import, data).

| Mètode | Funció |
|--------|--------|
| `guardarSaldoInicial` | Saldo inicial |
| `guardarIngreso` / `guardarRetirada` | Moviments amb data |
| `getFor` | Totals; opcionalment per rang de dates |
| `getMovements` / `updateMovementAmount` | Editar moviments |
| `deleteAccount` / `restoreAccount` | Eliminar o restaurar casa |

**Sincronització amb Configuració:** en guardar les llistes CSV a `ConfigFragment`, per a cada casa es crida `restoreAccount` perquè aparega a la pestanya **Comptes** encara que encara no hi hagi apuestas. `AnnualSummaryFragment` fa el mateix en carregar: restaura cases de la config i de les apuestas existents.

**Fórmula del saldo per casa:**

`saldo = inicial + dipòsits − retirades + benefici_apostes`

---

## 6. Navegació i arranc de l’app

### `MainActivity` (`MainActivity.kt`)

| Mètode | Funció |
|--------|--------|
| `onCreate` | Primer arranc → `WelcomeFragment`; configura bottom nav |
| `replaceMainFragment` | Canvi de pestanya; buida back stack |
| `openAddBetScreen` / `openEditBetScreen` | Formulari amb back stack |
| `openHomeFromWelcome` | Benvinguda → llista d’apostes + bottom nav |

**Flux de navegació:**

```
Primer arranc → WelcomeFragment
  → Empezar → BetsListFragment + bottom nav
Bottom nav → Apostes / Estadístiques / Comptes / Config
FAB / Editar → AddBetFragment (back stack; bottom nav oculta)
```

---

## 7. Pantalles i codi (Fragments)

### 7.1 `WelcomeFragment`

- Pantalla de benvinguda al primer arranc.
- Tutorial automàtic si `!hasSeenTutorial()`.
- **Empezar** → `openHomeFromWelcome()`.

### 7.2 `TutorialDialog`

Diàleg modal reutilitzable; text a `R.string.tutorial_message`. Accessible des de Configuració.

### 7.3 `BetsListFragment` — Llista d’apostes

**Funcionalitat:** llista amb filtres per data, resultat, casa i tipster; FAB per alta; verificar, editar i eliminar.

| Mètode clau | Funció |
|-------------|--------|
| `loadBets()` | Carrega des de Room en IO |
| `applyBetsFilter()` | Aplica tots els filtres |
| `showVerifyDialog()` | Canvia resultat sense formulari complet |
| `confirmDeleteBet()` | Diàleg de confirmació abans d’eliminar (evita borrats accidentals) |
| `deleteBet()` | Elimina i recarrega |

### 7.4 `BetsAdapter`

`RecyclerView` que mostra cada apuesta amb colors segons resultat (verd/roig/gris). Cada fila té botons explícits: **verificar** (✓), **editar** (làpiz) i **eliminar** (paperera). El callback `onEdit` obre `AddBetFragment` en mode edició.

### 7.5 `AddBetFragment` — Alta i edició

- Mode alta o edició (`newEditInstance(betId)`).
- Spinners des de `AppConfigStore` (només valors configurats per l’usuari).
- `trySave()` valida camps obligatoris, números i **saldo disponible** (`checkInsufficientBalance`).
- **Validació de saldo:** el stake no pot superar el saldo lliure de la casa (saldo inicial + dipòsits − retirades + benefici de resoltes − stakes de pendents). En edició es té en compte l’impacte de l’apuesta original.
- `applyInsetsForIme()` evita que el teclat tape el botó Guardar.

### 7.6 `StatsFragment` — Estadístiques

Filtres: període global/rang, àmbit (general/tipster/cuenta), tipus Live/PreMatch, mercat, esport.

Calcula sobre apostes **resoltes** (WON + LOST):

- Benefici net, total apostat, ROI (yield), encerts.
- Fórmules: `stake×(odds−1)`, `−stake`, hit rate, ROI.

### 7.7 `AnnualSummaryFragment` — Comptes per casa

Targeta per bookmaker amb saldo, dipòsits, retirades, benefici i saldo inicial. Clic → menú: dipositar, retirar, editar moviment, saldo inicial, eliminar compte. Validació: retirada ≤ saldo actual.

### 7.8 `ConfigFragment` — Configuració i dades

- Editar i guardar llistes CSV; en guardar, `restoreAccount` per a cada casa de la llista.
- Tutorial, eliminar totes les apostes (amb confirmació).
- Exportar/importar CSV d’apostes i comptes.

---

## 8. Fluxos d’ús per a la demostració

### Primera obertura
`PersonalBetApplication` → `WelcomeFragment` → tutorial (si cal) → **Empezar** → llista.

### Primera configuració (abans de la demo)
Configuració → omplir cases, tipsters, mercats i tipus → **Guardar** → comprovar que apareixen a **Comptes**.

### Registrar apuesta
FAB → formulari → validació (camps + saldo) → guardar → `insert` → torna a la llista.

### Editar apuesta
Botó **làpiz** a la fila → formulari preomplert → **Guardar canvis**.

### Eliminar apuesta
Botó **paperera** → diàleg de confirmació → eliminar.

### Verificar resultat
Botó verificar a la llista → tria pendent/guanyada/perduda → `updateResult`.

### Dipòsit en una casa
Pestanya Comptes → clic en targeta → dipositar → data i import.

### Exportar còpia de seguretat
Configuració → Exportar → `apuestas_export.csv` i `cuentas_export.csv` a Descargas/PersonalBet.

---

## 9. Exportació i importació CSV

### Apostes

```
id,fecha,casa,deporte,tipster,evento,cuota,stake,tipo_grupo,tipo_nombre,mercado,resultado
```

### Comptes

```
casa,saldo_inicial,depositos,retiros,beneficio_apuestas,saldo_final
```

La importació de comptes reinicia cada casa abans d’importar per evitar duplicats.

---

## 10. Preguntes freqüents

| Pregunta | Resposta |
|----------|----------|
| Per què Room i no només Preferences? | Moltes files, filtres, SQL; SQLite escala millor. |
| Per què Preferences per a comptes? | Pocs registres per casa; es combinen amb càlcul en Kotlin. |
| Com evites bloquejar la UI? | Coroutines amb `Dispatchers.IO`. |
| Com navegues? | Un `FragmentManager`, back stack només al formulari. |
| Migració de BD? | `MIGRATION_1_2` afegeix camps sense esborrar dades. |
| Validació del formulari? | Config no buida + camps obligatoris + números + stake ≤ saldo disponible (Snackbar). |
| Per què llistes buides per defecte? | Cada usuari professional té les seues cases i tipsters; no imposar valors ficticis. |
| Com apareixen comptes sense apuestas? | `restoreAccount` en guardar Config o en obrir Comptes. |
| Com s’edita una apuesta? | Botó làpiz a la llista (no cal pulsació llarga). |
| Es pot eliminar sense voler? | No: `confirmDeleteBet` demana confirmació abans de `delete`. |
| Yield i benefici? | Només resoltes; pendents excloses. |
| Per què diverses cases? | Comparar quotes; exemple València–Elx 1,70 vs 1,75. |
| L’app aposta en línia? | No. No connecta amb cases ni ofereix quotes en temps real. |
| Per a qui és? | Usuaris professionals: tipsters, apostadors avançats, gestió de bankroll. |
| Per què manual? | L’usuari ja té la jugada (tipster o pròpia) i la registra per analitzar rendiment. |

---

## 11. Resum per a tancar la presentació

PersonalBet és una aplicació Android completa per a gestió personal d’apostes esportives: registre, estadístiques amb yield/ROI, comptes per casa, exportació CSV i configuració flexible.

El codi està organitzat en capes — dades, configuració i interfície — amb tecnologies estàndard del temari DAM (Kotlin, Room, Fragments, Material Design).

El codi font està a GitHub (**almartar/PersonalBet**). La memòria completa, l’APK i aquest supertutorial formen part del suport USB del projecte.

---

*Supertutorial PersonalBet — IES Dr. Lluís Simarro — DAM — Curs 2025/2026*
